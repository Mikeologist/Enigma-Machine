#include <iostream>
using namespace std;

class Converter
{
public:
    Converter();
    string hexToDec(string hex);
    string octToDec(string oct);
    string binToDec(string bin);
    string decToHex(string dec);
    string decToOct(string dec);
    string decToBin(string dec);
};
