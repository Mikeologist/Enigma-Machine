#include <iostream>
using namespace std;

class Reflector
{
public:
    Reflector();
    //char* getSubValues();
    char getValueFor(char valInput);
    //void setSubValues(char patch1, char patch2);
};
