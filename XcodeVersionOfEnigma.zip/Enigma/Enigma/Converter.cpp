#include <iostream>
#include <cmath>
#include "Converter.h"
using namespace std;

char patchPanel[26];

Converter::Converter()
{
    
}

string Converter::hexToDec(string hex)
{
    int convert = 0;
    int length = hex.length();
    int power = 1;
    int next;
    char temp;
    string converted;
    
    for(int i = length; i > 0; i--)
    {
        temp = toupper(hex.at(length));
        
        if(temp >= '0' && temp <= '9')
        {
            next = temp - '0';
        }
        else if(temp >= 'A' && temp <= 'F')
        {
            next = temp - '7';
        }
        
        next = next * pow(16, power);
        convert += next;
        power++;
    }
    
    converted = convert;
    
    return converted;
}

string Converter::octToDec(string oct)
{
    int convert = 0;
    int length = oct.length();
    int power = 1;
    int next;
    char temp;
    string converted;
    
    for(int i = length; i > 0; i--)
    {
        temp = oct.at(length);
        
        next = temp - '0';
        
        next = next * pow(8, power);
        convert += next;
        power++;
    }
    
    converted = convert;
    
    return converted;
}

string Converter::binToDec(string bin)
{
    int convert = 0;
    int length = bin.length();
    int power = 1;
    int next;
    char temp;
    string converted;
    
    for(int i = length; i > 0; i--)
    {
        temp = bin.at(length);
        
        next = temp - '0';
        
        next = next * pow(2, power);
        convert += next;
        power++;
    }
    
    converted = convert;
    
    return converted;
}

string Converter::decToHex(string dec)
{
    int convert = 0;
    int decimal = stoi(dec);
    int length = dec.length();
    int power = 1;
    int next = 0;
    int temp;
    string converted;
    
    for(int i = 1; decimal > next; i++)
    {
        next = pow(16, power);
        power++;
    }
    
    for(int i = power; i >= 0; i--)
    {
        power--;
        next = pow(16, power);
        
        temp = decimal / next;
        decimal = decimal - (temp * next);
        
        convert += (temp * next);
    }
    
    converted = convert;
    
    return converted;
}

string Converter::decToOct(string dec)
{
    int convert = 0;
    int decimal = stoi(dec);
    int length = dec.length();
    int power = 1;
    int next = 0;
    int temp;
    string converted;
    
    for(int i = 1; decimal > next; i++)
    {
        next = pow(8, power);
        power++;
    }
    
    for(int i = power; i >= 0; i--)
    {
        power--;
        next = pow(8, power);
        
        temp = decimal / next;
        decimal = decimal - (temp * next);
        
        convert += (temp * next);
    }
    
    converted = convert;
    
    return converted;
}

string Converter::decToBin(string dec)
{
    int convert = 0;
    int decimal = stoi(dec);
    int length = dec.length();
    int power = 1;
    int next = 0;
    int temp;
    string converted;
    
    for(int i = 1; decimal > next; i++)
    {
        next = pow(2, power);
        power++;
    }
    
    for(int i = power; i >= 0; i--)
    {
        power--;
        next = pow(2, power);
        
        temp = decimal / next;
        decimal = decimal - (temp * next);
        
        convert += (temp * next);
    }
    
    converted = convert;
    
    return converted;
}
